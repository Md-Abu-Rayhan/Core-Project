﻿using ESLicense.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;

namespace Pension_GPF.Utility
{
    [Serializable]
    public abstract class CommonService
    {
        private static readonly string[] SizeSuffixes = new string[9]
        {
            "bytes",
            "KB",
            "MB",
            "GB",
            "TB",
            "PB",
            "EB",
            "ZB",
            "YB"
        };

        public static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> list = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                list.Add(item);
            }

            return list;
        }

        public static string ConvertDtToXmlString(DataTable table)
        {
            TextWriter textWriter = new StringWriter();
            table.WriteXml(textWriter);
            return textWriter.ToString();
        }

        public static List<T> CopyList<T>(List<T> lst)
        {
            List<T> list = new List<T>();
            foreach (T item in lst)
            {
                T val = Activator.CreateInstance<T>();
                ObjectToObject(item, val);
                list.Add(val);
            }

            return list;
        }

        public static string StrDecompress(string s)
        {
            byte[] buffer = Convert.FromBase64String(s);
            using (MemoryStream stream = new MemoryStream(buffer))
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (GZipStream gZipStream = new GZipStream(stream, CompressionMode.Decompress))
                    {
                        gZipStream.CopyTo(memoryStream);
                    }

                    return Encoding.Unicode.GetString(memoryStream.ToArray());
                }
            }
        }

        public static string StrCompress(string s)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(s);
            using (MemoryStream memoryStream2 = new MemoryStream(bytes))
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (GZipStream destination = new GZipStream(memoryStream, CompressionMode.Compress))
                    {
                        memoryStream2.CopyTo(destination);
                    }

                    return Convert.ToBase64String(memoryStream.ToArray());
                }
            }
        }

        public static string ListToJsonString<T>(List<T> list1, string partName1)
        {
            string text = JsonConvert.SerializeObject(list1);
            return "{\"" + partName1 + "\":" + text + "}";
        }

        public static string TakaEnToBanWithCommaSeparator(decimal enTaka)
        {
            string source = Comma_SeparatorTakaEng(Math.Round(Convert.ToDecimal(enTaka), 2));
            char[] array = new char[10]
            {
                '০',
                '১',
                '২',
                '৩',
                '৪',
                '৫',
                '৬',
                '৭',
                '৮',
                '৯'
            };
            string text = "";
            char[] array2 = source.ToArray();
            foreach (char c in array2)
            {
                char c2 = c;
                for (int j = 0; j <= 9; j++)
                {
                    if (c2.ToString() == j.ToString())
                    {
                        c2 = array[j];
                        break;
                    }
                }

                text += c2;
            }

            return text;
        }

        public static string Comma_SeparatorTakaEng(decimal amount)
        {
            string text = "";
            string text2 = "";
            string text3 = "";
            text2 = amount.ToString();
            int num = amount.ToString().IndexOf(".", 0);
            text3 = amount.ToString().Substring(num + 1);
            if (text2 == text3)
            {
                text3 = "";
            }
            else
            {
                text2 = amount.ToString().Substring(0, amount.ToString().IndexOf(".", 0));
                text2 = text2.Replace(",", "").ToString();
            }

            switch (text2.Length)
            {
                case 12:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 1) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 2) + "," + text2.Substring(6, 3);
                    }

                    return text2.Substring(0, 2) + "," + text2.Substring(2, 3) + "," + text2.Substring(5, 2) + "," + text2.Substring(7, 2) + "," + text2.Substring(9, 3) + "." + text3;
                case 11:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 1) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 2) + "," + text2.Substring(6, 3);
                    }

                    return text2.Substring(0, 1) + "," + text2.Substring(1, 3) + "," + text2.Substring(4, 2) + "," + text2.Substring(6, 2) + "," + text2.Substring(8, 3) + "." + text3;
                case 10:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 1) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 2) + "," + text2.Substring(6, 3);
                    }

                    return text2.Substring(0, 3) + "," + text2.Substring(3, 2) + "," + text2.Substring(5, 2) + "," + text2.Substring(7, 3) + "." + text3;
                case 9:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 2) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 2) + "," + text2.Substring(6, 3);
                    }

                    return text2.Substring(0, 2) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 2) + "," + text2.Substring(6, 3) + "." + text3;
                case 8:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 1) + "," + text2.Substring(1, 2) + "," + text2.Substring(3, 2) + "," + text2.Substring(5, 3);
                    }

                    return text2.Substring(0, 1) + "," + text2.Substring(1, 2) + "," + text2.Substring(3, 2) + "," + text2.Substring(5, 3) + "." + text3;
                case 7:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 2) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 3);
                    }

                    return text2.Substring(0, 2) + "," + text2.Substring(2, 2) + "," + text2.Substring(4, 3) + "." + text3;
                case 6:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 1) + "," + text2.Substring(1, 2) + "," + text2.Substring(3, 3);
                    }

                    return text2.Substring(0, 1) + "," + text2.Substring(1, 2) + "," + text2.Substring(3, 3) + "." + text3;
                case 5:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 2) + "," + text2.Substring(2, 3);
                    }

                    return text2.Substring(0, 2) + "," + text2.Substring(2, 3) + "." + text3;
                case 4:
                    if (text3 == "")
                    {
                        return text2.Substring(0, 1) + "," + text2.Substring(1, 3);
                    }

                    return text2.Substring(0, 1) + "," + text2.Substring(1, 3) + "." + text3;
                default:
                    if (text3 == "")
                    {
                        return text2;
                    }

                    return text2 + "." + text3;
            }
        }

        public static string DateToBangla(string enNumInp, string type = "")
        {
            char[] array = new char[10]
            {
                '০',
                '১',
                '২',
                '৩',
                '৪',
                '৫',
                '৬',
                '৭',
                '৮',
                '৯'
            };
            string[] array2 = new string[12]
            {
                "জ\u09beন\u09c1",
                "ফ\u09c7ব\u09cdর\u09c1",
                "ম\u09beর\u09cdচ",
                "এপ\u09cdর\u09bf",
                "ম\u09c7",
                "জ\u09c1ন",
                "জ\u09c1ল\u09beই",
                "আগস\u09cdট",
                "স\u09c7প\u09cdট\u09c7",
                "অক\u09cdট\u09cb",
                "নভ\u09c7",
                "ড\u09bfস\u09c7"
            };
            string[] array3 = new string[12]
            {
                "জ\u09beন\u09c1য়\u09beর\u09bf",
                "ফ\u09c7ব\u09cdর\u09c1য়\u09beর\u09bf",
                "ম\u09beর\u09cdচ",
                "এপ\u09cdর\u09bfল",
                "ম\u09c7",
                "জ\u09c1ন",
                "জ\u09c1ল\u09beই",
                "আগস\u09cdট",
                "স\u09c7প\u09cdট\u09c7ম\u09cdবর",
                "অক\u09cdট\u09cbবর",
                "নভ\u09c7ম\u09cdবর",
                "ড\u09bfস\u09c7ম\u09cdবর"
            };
            string[] array4 = new string[12]
            {
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December"
            };
            string text = "";
            char[] array5 = enNumInp.ToArray();
            foreach (char c in array5)
            {
                char c2 = c;
                for (int j = 0; j <= 9; j++)
                {
                    if (c2.ToString() == j.ToString())
                    {
                        c2 = array[j];
                        break;
                    }
                }

                text += c2;
            }

            for (int k = 0; k < 12; k++)
            {
                if (text.Contains(array4[k]))
                {
                    text = text.Replace(array4[k], array3[k].ToString());
                    break;
                }

                if (text.Contains(array4[k].Substring(0, 3)))
                {
                    text = ((!(type == "FULLNAME")) ? text.Replace(array4[k].Substring(0, 3), array2[k]) : text.Replace(array4[k].Substring(0, 3), array3[k]));
                    break;
                }
            }

            return text;
        }

        public static string DateToBanglaMin(string enNumInp, string type = "")
        {
            char[] array = new char[10]
            {
                '০',
                '১',
                '২',
                '৩',
                '৪',
                '৫',
                '৬',
                '৭',
                '৮',
                '৯'
            };
            string[] array2 = new string[12]
            {
                "জ\u09beন\u09c1",
                "ফ\u09c7ব\u09cdর\u09c1",
                "ম\u09beর\u09cdচ",
                "এপ\u09cdর\u09bf",
                "ম\u09c7",
                "জ\u09c1ন",
                "জ\u09c1ল\u09beই",
                "আগস\u09cdট",
                "স\u09c7প\u09cdট\u09c7",
                "অক\u09cdট\u09cb",
                "নভ\u09c7",
                "ড\u09bfস\u09c7"
            };
            string[] array3 = new string[12]
            {
                "জ\u09beন\u09c1য়\u09beর\u09bf",
                "ফ\u09c7ব\u09cdর\u09c1য়\u09beর\u09bf",
                "ম\u09beর\u09cdচ",
                "এপ\u09cdর\u09bfল",
                "ম\u09c7",
                "জ\u09c1ন",
                "জ\u09c1ল\u09beই",
                "আগস\u09cdট",
                "স\u09c7প\u09cdট\u09c7ম\u09cdবর",
                "অক\u09cdট\u09cbবর",
                "নভ\u09c7ম\u09cdবর",
                "ড\u09bfস\u09c7ম\u09cdবর"
            };
            string[] array4 = new string[12]
            {
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December"
            };
            string text = "";
            char[] array5 = enNumInp.ToArray();
            foreach (char c in array5)
            {
                char c2 = c;
                for (int j = 0; j <= 9; j++)
                {
                    if (c2.ToString() == j.ToString())
                    {
                        c2 = array[j];
                        break;
                    }
                }

                text += c2;
            }

            for (int k = 0; k < 12; k++)
            {
                if (text.Contains(array4[k]))
                {
                    text = text.Replace(array4[k], array3[k].ToString());
                    break;
                }

                if (text.Contains(array4[k].Substring(0, 3)))
                {
                    text = ((!(type == "FULLNAME")) ? text.Replace(array4[k].Substring(0, 3), array2[k]) : text.Replace(array4[k].Substring(0, 3), array3[k]));
                    break;
                }
            }

            return text;
        }

        private static T GetItem<T>(DataRow dr)
        {
            Type typeFromHandle = typeof(T);
            T val = Activator.CreateInstance<T>();
            foreach (DataColumn column in dr.Table.Columns)
            {
                PropertyInfo[] properties = typeFromHandle.GetProperties();
                foreach (PropertyInfo propertyInfo in properties)
                {
                    if (propertyInfo.Name == column.ColumnName)
                    {
                        propertyInfo.SetValue(val, dr[column.ColumnName], null);
                    }
                }
            }

            return val;
        }

        private static void ObjectToObject(object source, object destination)
        {
            Type type = source.GetType();
            Type type2 = destination.GetType();
            PropertyInfo[] properties2 = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
            PropertyInfo[] properties3 = type2.GetProperties(BindingFlags.Instance | BindingFlags.Public);
            List<string> propertyNames = properties2.Select((PropertyInfo c) => c.Name).ToList();
            foreach (PropertyInfo item in properties3.Where((PropertyInfo properties) => propertyNames.Contains(properties.Name)))
            {
                try
                {
                    PropertyInfo property = source.GetType().GetProperty(item.Name);
                    item.SetValue(destination, property.GetValue(source, null), null);
                }
                catch
                {
                    throw;
                }
            }
        }

        public static string DateBanglaToEnglish(string bnNumInp)
        {
            char[] array = new char[10]
            {
                '০',
                '১',
                '২',
                '৩',
                '৪',
                '৫',
                '৬',
                '৭',
                '৮',
                '৯'
            };
            char[] array2 = new char[10]
            {
                '0',
                '1',
                '2',
                '3',
                '4',
                '5',
                '6',
                '7',
                '8',
                '9'
            };
            string[] array3 = new string[12]
            {
                "জ\u09beন\u09c1",
                "ফ\u09c7ব\u09cdর\u09c1",
                "ম\u09beর\u09cdচ",
                "এপ\u09cdর\u09bf",
                "ম\u09c7",
                "জ\u09c1ন",
                "জ\u09c1ল\u09be",
                "আগ",
                "স\u09c7প\u09cdট\u09c7",
                "অক\u09cdট\u09cb",
                "নভ\u09c7",
                "ড\u09bfস\u09c7"
            };
            string[] array4 = new string[12]
            {
                "জ\u09beন\u09c1য়\u09beর\u09bf",
                "ফ\u09c7ব\u09cdর\u09c1য়\u09beর\u09bf",
                "ম\u09beর\u09cdচ",
                "এপ\u09cdর\u09bfল",
                "ম\u09c7",
                "জ\u09c1ন",
                "জ\u09c1ল\u09beই",
                "আগস\u09cdট",
                "স\u09c7প\u09cdট\u09c7ম\u09cdবর",
                "অক\u09cdট\u09cbবর",
                "নভ\u09c7ম\u09cdবর",
                "ড\u09bfস\u09c7ম\u09cdবর"
            };
            string[] array5 = new string[12]
            {
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December"
            };
            string[] array6 = new string[12]
            {
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            };
            string text = "";
            char[] array7 = bnNumInp.ToArray();
            foreach (char c in array7)
            {
                char c2 = c;
                for (int j = 0; j <= 9; j++)
                {
                    if (c2.ToString() == array[j].ToString())
                    {
                        c2 = array[j];
                        break;
                    }
                }

                text += c2;
            }

            for (int k = 0; k < 12; k++)
            {
                if (text.Contains(array4[k]))
                {
                    text = text.Replace(array4[k], array5[k].ToString());
                    break;
                }

                if (text.Contains(array3[k]))
                {
                    text = text.Replace(array4[k].Substring(0, 3), array6[k]);
                    break;
                }
            }

            return text;
        }

        public static string NumberEngToBan(string enNumInp)
        {
            char[] array = new char[10]
            {
                '০',
                '১',
                '২',
                '৩',
                '৪',
                '৫',
                '৬',
                '৭',
                '৮',
                '৯'
            };
            string text = "";
            char[] array2 = enNumInp.ToArray();
            foreach (char c in array2)
            {
                char c2 = c;
                for (int j = 0; j <= 9; j++)
                {
                    if (c2.ToString() == j.ToString())
                    {
                        c2 = array[j];
                        break;
                    }
                }

                text += c2;
            }

            return text;
        }

        public static string GetFileSizeSuffix(long value, int decimalPlaces = 1)
        {
            if (decimalPlaces < 0)
            {
                throw new ArgumentOutOfRangeException("decimalPlaces");
            }

            if (value < 0)
            {
                return "-" + GetFileSizeSuffix(-value, decimalPlaces);
            }

            if (value == 0)
            {
                return string.Format("{0:n" + decimalPlaces + "} bytes", 0);
            }

            int num = (int)Math.Log(value, 1024.0);
            decimal num2 = (decimal)value / (decimal)(1L << num * 10);
            if (Math.Round(num2, decimalPlaces) >= 1000m)
            {
                num++;
                num2 /= 1024m;
            }

            return string.Format("{0:n" + decimalPlaces + "} {1}", num2, SizeSuffixes[num]);
        }

        public static Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
            {
                {
                    ".txt",
                    "text/plain"
                },
                {
                    ".pdf",
                    "application/pdf"
                },
                {
                    ".doc",
                    "application/vnd.ms-word"
                },
                {
                    ".docx",
                    "application/vnd.ms-word"
                },
                {
                    ".ppt",
                    "application/vnd.ms-powerpoint"
                },
                {
                    ".pptx",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                },
                {
                    ".xls",
                    "application/vnd.ms-excel"
                },
                {
                    ".xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                },
                {
                    ".png",
                    "image/png"
                },
                {
                    ".jpg",
                    "image/jpeg"
                },
                {
                    ".jpeg",
                    "image/jpeg"
                },
                {
                    ".gif",
                    "image/gif"
                },
                {
                    ".csv",
                    "text/csv"
                },
                {
                    ".sql",
                    "application/octet-stream"
                },
                {
                    ".apk",
                    "application/vnd.android.package-archive"
                }
            };
        }

        public static string ListToXml<T>(T obj)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            using (StringWriter stringWriter = new StringWriter())
            {
                xmlSerializer.Serialize(stringWriter, obj);
                return stringWriter.ToString();
            }
        }

        public static string ListToXml<T>(T obj, string rootName)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), new XmlRootAttribute(rootName));
            XmlSerializerNamespaces xmlSerializerNamespaces = new XmlSerializerNamespaces();
            xmlSerializerNamespaces.Add(string.Empty, string.Empty);
            using (StringWriter stringWriter = new StringWriter())
            {
                xmlSerializer.Serialize(stringWriter, obj, xmlSerializerNamespaces);
                return stringWriter.ToString();
            }
        }

        public static string EncodeProcessParameters(ProcessParametersModel parameters)
        {
            string s = JsonConvert.SerializeObject(parameters);
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            return Convert.ToBase64String(bytes);
        }

        public static ProcessParametersModel DecodePocessParameters(object parameters)
        {
            byte[] bytes = Convert.FromBase64String(parameters.ToString());
            string @string = Encoding.UTF8.GetString(bytes);
            return JsonConvert.DeserializeObject<ProcessParametersModel>(@string.ToString());
        }

        public static string CompressSerializeObject(object? value, Formatting formatting)
        {
            string s = JsonConvert.SerializeObject(value, Formatting.Indented);
            return StrCompress(s);
        }
    }
}
